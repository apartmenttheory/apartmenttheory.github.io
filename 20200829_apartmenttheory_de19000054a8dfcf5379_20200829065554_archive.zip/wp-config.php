<?php

/**

 * The base configuration for WordPress

 *

 * The wp-config.php creation script uses this file during the

 * installation. You don't have to use the web site, you can

 * copy this file to "wp-config.php" and fill in the values.

 *

 * This file contains the following configurations:

 *

 * * MySQL settings

 * * Secret keys

 * * Database table prefix

 * * ABSPATH

 *

 * @link https://wordpress.org/support/article/editing-wp-config-php/

 *

 * @package WordPress

 */


// ** MySQL settings - You can get this info from your web host ** //

/** The name of the database for WordPress */

define( 'DB_NAME', '' );


/** MySQL database username */

define( 'DB_USER', '' );


/** MySQL database password */

define( 'DB_PASSWORD', '' );


/** MySQL hostname */

define( 'DB_HOST', '' );


/** Database Charset to use in creating database tables. */

define( 'DB_CHARSET', 'utf8mb4' );


/** The Database Collate type. Don't change this if in doubt. */

define( 'DB_COLLATE', '' );


/**#@+

 * Authentication Unique Keys and Salts.

 *

 * Change these to different unique phrases!

 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}

 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.

 *

 * @since 2.6.0

 */

define( 'AUTH_KEY',         'T;-Z~NJK85b6GBlN?%J,5F180IAWq#K/{;Vvj7B&l:lQe<Rrj5SHH0>Rtq3zB]Yw' );

define( 'SECURE_AUTH_KEY',  ' u7P3u0{$#/IKcm9vRBfNs33iN+| -Wnq;oZM>Nx[G,f51E~z1ZUxgdKTP12ez$$' );

define( 'LOGGED_IN_KEY',    'wT2)X{dAI:Z)Y)MRHui-1,|9%^@lxVi0|4qaNAN]uKLsN`g?Z+3nvMa5xRn5^L9q' );

define( 'NONCE_KEY',        'oHZ]IBb;3t<;(+6zb94?kUb/;u=YsDDI!z1@cO]&/@L@X<gQpH;}X&~5}qBjMoed' );

define( 'AUTH_SALT',        'U^rdm<nz@*a&X$fbz:-WeBWvc>Ud-u<M4SwuU[])03YinL#I6D5$wk*Sun4U~Akw' );

define( 'SECURE_AUTH_SALT', 'IpPlbkXVjr[6u?=&Ft`&Uf+L[~X!q|$9AGh99 bb~K$iT[&o1E;e`/sbFs.c4;F)' );

define( 'LOGGED_IN_SALT',   '$Af/hzm3,Y}vC_0noGf0s6oBf|AxMxW|6d|mct,gF,8HSnCh}gMSe8,wMGZE2{s}' );

define( 'NONCE_SALT',       '({u}1ZfNHOzt6=USmb4JS(^8%}T,u-oag,0;L`vAzcha!D%kir&uaCkWO3cQ07a^' );


/**#@-*/


/**

 * WordPress Database Table prefix.

 *

 * You can have multiple installations in one database if you give each

 * a unique prefix. Only numbers, letters, and underscores please!

 */

$table_prefix = 'wp_';


/**

 * For developers: WordPress debugging mode.

 *

 * Change this to true to enable the display of notices during development.

 * It is strongly recommended that plugin and theme developers use WP_DEBUG

 * in their development environments.

 *

 * For information on other constants that can be used for debugging,

 * visit the documentation.

 *

 * @link https://wordpress.org/support/article/debugging-in-wordpress/

 */

define( 'WP_DEBUG', false );


/* That's all, stop editing! Happy publishing. */


/** Absolute path to the WordPress directory. */

if ( ! defined( 'ABSPATH' ) ) {

	define( 'ABSPATH', __DIR__ . '/' );

}


/** Sets up WordPress vars and included files. */

require_once ABSPATH . 'wp-settings.php';

